# SecureID

SecureID is a full React/Vite + Express identity-wallet application with server-backed authentication, MFA, adaptive risk controls, phishing checks, selective sharing and emergency wallet locking.

## Included functionality

- Account registration and sign-in with bcrypt password hashing.
- HttpOnly, SameSite session cookies with server-side session storage.
- Six-digit MFA challenges with short expiry, hashed OTP storage, cooldowns and rate limits.
- Risk engine with persistent wallet risk state and MFA escalation at high risk.
- Emergency wallet lock with server-side state.
- Selective identity-claim sharing with a generated share token.
- Basic phishing-indicator scanner for HTTPS, suspicious hostnames, Unicode hostnames and unusually deep domains.
- Security-event logging for account creation, successful login, MFA verification, logout, high-risk detection, wallet locking and sharing.
- SQLite persistence for local/single-instance deployments.
- Production security headers, CORS controls, HTTPS requirements and verified email-sender enforcement.

## Local development

Use Node.js 24 or newer. Create `.env` from `.env.example` and set stable `SESSION_HASH_SECRET` and `OTP_HASH_SECRET` values of at least 32 characters.

For development without email delivery, use:

```text
OTP_DELIVERY=console
```

The development API prints the generated OTP to its own terminal. For real email delivery, use `OTP_DELIVERY=resend`, a Resend API key and a verified sender address.

Run the API and frontend:

```powershell
npm install
npm run dev:api
npm run dev
```

Open the Vite URL shown by the frontend, normally `http://127.0.0.1:5173`.

## Production

Production requires:

- `NODE_ENV=production`
- HTTPS `APP_ORIGIN`
- `SESSION_HASH_SECRET` and `OTP_HASH_SECRET`
- `OTP_DELIVERY=resend`
- `RESEND_API_KEY`
- A verified non-`resend.dev` `OTP_FROM_EMAIL`
- Durable protected `DATABASE_PATH`
- Correct `TRUST_PROXY_HOPS` when behind a reverse proxy

Use a deployment secret manager for credentials. Never commit `.env`, database files or logs.

The current database design is intended for a single application instance. A horizontally scaled deployment should move wallet/session/rate-limit storage to shared managed infrastructure.

## Verification

```powershell
npm run lint
npm run build
```
