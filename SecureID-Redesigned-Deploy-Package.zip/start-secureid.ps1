$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$root'; npm run dev:api"
Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$root'; npm run dev"
