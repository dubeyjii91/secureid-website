@echo off
setlocal
cd /d "%~dp0"
if not exist package.json (
  echo SecureID installation is incomplete.
  pause
  exit /b 1
)
where node >nul 2>&1 || (
  echo Node.js is required to run SecureID.
  pause
  exit /b 1
)
if not exist node_modules\.bin\vite.cmd (
  echo Installing SecureID dependencies...
  call npm ci
  if errorlevel 1 goto :fail
)
if not exist dist\index.html (
  echo Building SecureID...
  call npm run build
  if errorlevel 1 goto :fail
)
start "SecureID Server" /min cmd /c "npm run start"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:5000"
exit /b 0
:fail
echo SecureID could not finish setup.
pause
exit /b 1
