SecureID Desktop

Double-click "SecureID Desktop.cmd" to start SecureID. The launcher installs dependencies if needed, builds the web application, starts the local server, and opens SecureID in your browser.

The requested account is pre-seeded in the local database. The password is stored only as a bcrypt hash.

Local address: http://127.0.0.1:5000
